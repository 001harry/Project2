
# FlyAway - Airline Booking Portal

## Description
FlyAway is a web-based airline ticket-booking portal that allows users to search for and book flights. Admin users can manage flight details, airlines, and available places.

## Features
- User can search for flights based on travel details.
- Display available flights with their ticket prices.
- User registration and personal detail input for booking.
- Dummy payment gateway integration.
- Booking confirmation details displayed to user.
- Admin backend to manage airlines, flights, and available places.
- Admin authentication and password update feature.

## Tech Stack
- Spring Boot
- Thymeleaf
- JPA (with Hibernate)
- MySQL
- Maven

## Setup
1. Clone the repository from GitHub.
2. Set up a MySQL database and update the `application.properties` with your database credentials.
3. Navigate to the project directory.
4. Run `mvn clean install` to build the project.
5. Run `mvn spring-boot:run` to start the application.
6. Access the application at `http://localhost:8080/`.

## Usage
- Open the application in a web browser.
- Use the search form on the homepage to find available flights.
- Follow the steps to book a flight, input personal details, and complete the payment.
- For admin features, navigate to `/admin`.

## Contributing
This is a sample project and not open for contribution. However, feedback and suggestions are always welcome.

