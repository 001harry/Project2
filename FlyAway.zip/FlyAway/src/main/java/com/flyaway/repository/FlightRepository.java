package com.flyaway.repository;

import com.flyaway.model.Flight;
import com.flyaway.model.Place;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface FlightRepository extends JpaRepository<Flight, Long> {

    List<Flight> findBySourceAndDestinationAndDate(Place source, Place destination, LocalDate date);

}
