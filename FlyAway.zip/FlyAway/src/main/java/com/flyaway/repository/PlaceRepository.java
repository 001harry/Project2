package com.flyaway.repository;

import com.flyaway.model.Place;
import org.springframework.data.repository.CrudRepository;

public interface PlaceRepository extends CrudRepository<Place, Long> {

	Place findByName(String source);
}
