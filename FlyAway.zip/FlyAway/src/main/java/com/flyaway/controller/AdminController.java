
package com.flyaway.controller;

import com.flyaway.model.Admin;
import com.flyaway.model.Airline;
import com.flyaway.model.Flight;
import com.flyaway.model.Place;
import com.flyaway.repository.AdminRepository;
import com.flyaway.repository.AirlineRepository;
import com.flyaway.repository.FlightRepository;
import com.flyaway.repository.PlaceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AdminController {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private AirlineRepository airlineRepository;

    @Autowired
    private FlightRepository flightRepository;

    @Autowired
    private PlaceRepository placeRepository;

    @GetMapping("/admin")
    public String adminLogin(Model model) {
        model.addAttribute("admin", new Admin());
        return "admin";
    }

    // ... (all the existing methods)

    @GetMapping("/admin-signup")
    public String showSignupForm() {
        return "admin-signup";
    }

    @PostMapping("/admin/create-account")
    public String createAdminAccount(@RequestParam String username, 
                                     @RequestParam String password, 
                                     @RequestParam(required=false) String secretKey, 
                                     Model model) {
        try {
            // Check if admin with the provided username already exists
            Admin existingAdmin = adminRepository.findByUsername(username);
            if (existingAdmin != null) {
                model.addAttribute("error", "An admin with this username already exists. Please choose a different username.");
                return "admin-signup";
            }

            // Print the submitted data for debugging.
            System.out.println("Username: " + username);
            System.out.println("Password: " + password);
            System.out.println("Secret Key: " + secretKey);
            
            // Create and save the new admin to the database.
            Admin admin = new Admin();
            admin.setUsername(username);
            admin.setPassword(password);  // Consider using a password encoder here for security
            admin.setSecretKey(secretKey); 
            adminRepository.save(admin);

            // Redirect to admin login page after sign-up.
            return "redirect:/admin";
        } catch (Exception e) {
            // Handle any errors that might occur.
            model.addAttribute("error", "An error occurred while creating the account. Please try again.");
            return "admin-signup";  // Return to the sign-up page to show the error
        }
    }
}
