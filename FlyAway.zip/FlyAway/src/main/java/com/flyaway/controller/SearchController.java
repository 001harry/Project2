package com.flyaway.controller;

import com.flyaway.model.Flight;
import com.flyaway.repository.FlightRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class SearchController {

    @Autowired
    private FlightRepository flightRepository;

    @GetMapping("/search")
    public String searchForm(Model model) {
        model.addAttribute("flight", new Flight());
        return "search";
    }

    @PostMapping("/search")
    public String searchSubmit(@ModelAttribute Flight flight, Model model) {
        List<Flight> flights = flightRepository.findBySourceAndDestinationAndDate(
                flight.getSource(), flight.getDestination(), flight.getDate());
        model.addAttribute("flights", flights);
        
    
    if (flights == null || flights.isEmpty()) {
        model.addAttribute("errorMessage", "No flights found for the given criteria. Please try again.");
        return "search";
    }
    return "result";
    
    
    }
}
