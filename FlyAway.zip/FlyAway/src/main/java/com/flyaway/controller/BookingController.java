package com.flyaway.controller;

import com.flyaway.model.Flight;
import com.flyaway.repository.FlightRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class BookingController {

    @Autowired
    private FlightRepository flightRepository;

    @GetMapping("/booking/{id}")
    public String bookingForm(@PathVariable("id") Long id, Model model) {
        Flight flight = flightRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid flight Id:" + id));
        model.addAttribute("flight", flight);
        return "booking";
    }

    @PostMapping("/booking")
    public String bookingSubmit(@ModelAttribute Flight flight, Model model) {
        // Here we would normally process the booking using a service
        // For this example, we just confirm the booking immediately
        model.addAttribute("flight", flight);
        
    return "register";  // Redirecting to the registration page after selecting a flight
    
    }
}
