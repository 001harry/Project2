
-- Inserting dummy data for Admin
INSERT INTO admin (username, password, secretKey) VALUES ('adminUser', 'strongPassword', 'AdminSecretKey123');

-- Inserting dummy data for Airline
INSERT INTO airline (name) VALUES ('Delta Airlines');
INSERT INTO airline (name) VALUES ('American Airlines');
INSERT INTO airline (name) VALUES ('United Airlines');
INSERT INTO airline (name) VALUES ('Southwest Airlines');

-- Inserting dummy data for Place
INSERT INTO place (name) VALUES ('New York City, NY');
INSERT INTO place (name) VALUES ('Los Angeles, CA');
INSERT INTO place (name) VALUES ('Chicago, IL');
INSERT INTO place (name) VALUES ('Houston, TX');
INSERT INTO place (name) VALUES ('Miami, FL');

-- Inserting dummy data for Flight
INSERT INTO flight (source_id, destination_id, airline_id, price) VALUES (1, 2, 1, 250.50);
INSERT INTO flight (source_id, destination_id, airline_id, price) VALUES (2, 3, 2, 210.00);
INSERT INTO flight (source_id, destination_id, airline_id, price) VALUES (3, 4, 3, 180.75);
INSERT INTO flight (source_id, destination_id, airline_id, price) VALUES (4, 5, 4, 300.30);
INSERT INTO flight (source_id, destination_id, airline_id, price) VALUES (5, 1, 1, 275.25);
